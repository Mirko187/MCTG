create table users
(
    user_id      serial
        primary key,
    username     varchar(255)                                                         not null,
    password     varchar(255)                                                         not null,
    last_login   timestamp default '1955-07-27 00:00:00'::timestamp without time zone not null,
    coins        integer   default 20                                                 not null,
    elo          integer   default 1000                                               not null,
    games_played integer   default 0                                                  not null,
    wins         integer   default 0                                                  not null
);

alter table users
    owner to postgres;

create table cards
(
    card_id     serial
        primary key,
    name        varchar(255)      not null,
    card_rounds integer default 0 not null,
    card_wins   integer default 0 not null,
    card_damage integer           not null,
    card_id2    varchar(36)
        constraint cards_pk
            unique,
    element     varchar(36),
    type        varchar(36)
);

alter table cards
    owner to postgres;

create table ownership
(
    ownership_id serial,
    owner_id     integer
        references users,
    date_start   timestamp                                                                  not null,
    date_end     timestamp default '2999-12-31 23:59:59.99999'::timestamp without time zone not null,
    card_id      integer                                                                    not null
        references cards
);

alter table ownership
    owner to postgres;

create table battles
(
    battle_id   serial
        primary key,
    user1_id    integer   not null
        references users,
    user2_id    integer   not null
        references users,
    battle_date timestamp not null,
    winner      integer   not null
);

alter table battles
    owner to postgres;

create table battle_rounds
(
    round_id      serial
        primary key,
    battle_id     integer not null
        references battles,
    user1_card_id integer not null
        references cards,
    user2_card_id integer not null
        references cards,
    winner        integer not null
);

alter table battle_rounds
    owner to postgres;

create table packages
(
    package_id  serial
        primary key,
    card1_id2   varchar(36) not null
        references cards (card_id2),
    card2_id2   varchar(36) not null
        references cards (card_id2),
    card3_id2   varchar(36) not null
        references cards (card_id2),
    card4_id2   varchar(36) not null
        references cards (card_id2),
    card5_id2   varchar(36) not null
        references cards (card_id2),
    is_availabe boolean default true
);

alter table packages
    owner to postgres;

create table decks
(
    deck_id   serial
        primary key,
    card1_id2 varchar(36) not null
        references cards (card_id2),
    card2_id2 varchar(36) not null
        references cards (card_id2),
    card3_id2 varchar(36) not null
        references cards (card_id2),
    card4_id2 varchar(36) not null
        references cards (card_id2),
    user_id int not null
        references users(user_id)
);

alter table decks
    owner to postgres;

create table queue
(
    id      serial
        primary key,
    user_id integer not null
        references users
);

alter table queue
    owner to postgres;