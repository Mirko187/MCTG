package at.technikum.apps.mtcg.interfaces;

import at.technikum.apps.mtcg.interfaces.AbstractController;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.assertEquals;

public class AbstractControllerTest {

    @Test
    public void testStatus_OK() {
        AbstractController abstractController = new AbstractControllerStub();

        HttpStatus httpStatusOK = HttpStatus.OK;
        Response responseOK = abstractController.status(httpStatusOK);
        assertEquals(httpStatusOK, responseOK.getStatus());
        assertEquals("{ \"error\": \"" + httpStatusOK.getMessage() + "\"}", responseOK.getBody());
    }

    @Test
    public void testStatus_NOT_FOUND() {
        AbstractController abstractController = new AbstractControllerStub();

        HttpStatus httpStatusNotFound = HttpStatus.NOT_FOUND;
        Response responseNotFound = abstractController.status(httpStatusNotFound);
        assertEquals(httpStatusNotFound, responseNotFound.getStatus());
        assertEquals("{ \"error\": \"" + httpStatusNotFound.getMessage() + "\"}", responseNotFound.getBody());
    }

    private static class AbstractControllerStub extends AbstractController {
        public AbstractControllerStub() {
            super(null);
        }

        @Override
        public boolean supports(String route) {
            return false;
        }

        @Override
        public Response handle(Request request) {
            return null;
        }
    }
}
