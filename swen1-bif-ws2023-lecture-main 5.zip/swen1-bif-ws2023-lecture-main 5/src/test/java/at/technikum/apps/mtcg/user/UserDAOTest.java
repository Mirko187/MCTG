package at.technikum.apps.mtcg.user;

import at.technikum.apps.mtcg.interfaces.Database;
import at.technikum.apps.mtcg.user.User;
import at.technikum.apps.mtcg.user.UserDAO;
import org.junit.Before;
import org.junit.Test;
import org.mockito.Mockito;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.util.Optional;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertTrue;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.mock;
import static org.mockito.Mockito.when;

public class UserDAOTest {

    private UserDAO userDAO;
    private Database mockDatabase;

    @Before
    public void setUp() {
        mockDatabase = mock(Database.class);
        userDAO = new UserDAO(mockDatabase);
    }

    @Test
    public void testGetById_UserFound() throws SQLException {

        long userId = 1L;
        String[] parameters = {String.valueOf(userId)};
        ResultSet mockResultSet = mockResultSetWithUser();


        when(mockDatabase.executeQuery(any(), any())).thenReturn(mockResultSet);


        Optional<User> result = userDAO.getById(userId);


        assertTrue(result.isPresent());
        assertEquals("testuser", result.get().getUsername());
        assertEquals("testpassword", result.get().getPassword());
    }

    @Test
    public void testGetById_UserNotFound() throws SQLException {

        long userId = 2L;
        String[] parameters = {String.valueOf(userId)};
        ResultSet mockResultSet = mockResultSetWithoutUser();


        when(mockDatabase.executeQuery(any(), any())).thenReturn(mockResultSet);


        Optional<User> result = userDAO.getById(userId);


        assertFalse(result.isPresent());
    }

    @Test
    public void testGetByUsername_UserFound() throws SQLException {

        String username = "testuser";
        String[] parameters = {username};
        ResultSet mockResultSet = mockResultSetWithUser();


        when(mockDatabase.executeQuery(any(), any())).thenReturn(mockResultSet);


        Optional<User> result = userDAO.getByUsername(username);


        assertTrue(result.isPresent());
        assertEquals("testuser", result.get().getUsername());
        assertEquals("testpassword", result.get().getPassword());
    }

    @Test
    public void testGetByUsername_UserNotFound() throws SQLException {

        String username = "nonexistentuser";
        String[] parameters = {username};
        ResultSet mockResultSet = mockResultSetWithoutUser();


        when(mockDatabase.executeQuery(any(), any())).thenReturn(mockResultSet);


        Optional<User> result = userDAO.getByUsername(username);


        assertFalse(result.isPresent());
    }

    @Test
    public void testSave_UserSavedSuccessfully() throws SQLException {

        User testUser = new User("newuser", "newpassword");
        String[] parameters = {testUser.getUsername(), testUser.getPassword()};
        when(mockDatabase.executeUpdate(any(), any())).thenReturn(1); // Assume the save was successful

        userDAO.save(testUser);
    }

    private ResultSet mockResultSetWithUser() throws SQLException {
        ResultSet mockResultSet = mock(ResultSet.class);
        when(mockResultSet.next()).thenReturn(true);
        when(mockResultSet.getInt("user_id")).thenReturn(1);
        when(mockResultSet.getString("username")).thenReturn("testuser");
        when(mockResultSet.getString("password")).thenReturn("testpassword");
        when(mockResultSet.getTimestamp("last_login")).thenReturn(Timestamp.valueOf("2022-01-01 12:00:00"));
        return mockResultSet;
    }

    private ResultSet mockResultSetWithoutUser() throws SQLException {
        ResultSet mockResultSet = mock(ResultSet.class);
        when(mockResultSet.next()).thenReturn(false);
        return mockResultSet;
    }
}