package at.technikum.apps.mtcg.persistance;

import at.technikum.apps.mtcg.interfaces.Database;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

public class PostgresDatabaseTest {

    @InjectMocks
    private PostgresDatabase postgresDatabase;

    @Mock
    private Connection mockConnection;

    @Mock
    private PreparedStatement mockStatement;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testIsInteger_IntegerValue_ReturnsTrue() {
        assertTrue(PostgresDatabase.isInteger("123"));
    }

    @Test
    public void testIsInteger_NonIntegerValue_ReturnsFalse() {
        assertFalse(PostgresDatabase.isInteger("abc"));
    }
}
