package at.technikum.apps.mtcg.transaction;

import at.technikum.apps.mtcg.session.auth.AuthTokenService;
import at.technikum.apps.mtcg.user.User;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.when;

public class TransactionControllerTest {

    @InjectMocks
    private TransactionController transactionController;

    @Mock
    private AuthTokenService authTokenService;
    @Mock
    private TransactionService transactionService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testAcquirePackage_Failure() {
        Request request = new Request("POST", "/transactions/packages", "http://localhost");
        User user = new User();
        user.setId(123);
        String authToken = "invalid-auth-token";
        request.setAuthorization(authToken);

        when(authTokenService.getUserFromToken(authToken)).thenReturn(user);
        when(transactionService.acquirePackage(user)).thenReturn(false);

        Response response = transactionController.acquirePackage(request);

        assertEquals(HttpStatus.BAD_REQUEST, response.getStatus());
        assertEquals("No Success", response.getBody());
    }

}
