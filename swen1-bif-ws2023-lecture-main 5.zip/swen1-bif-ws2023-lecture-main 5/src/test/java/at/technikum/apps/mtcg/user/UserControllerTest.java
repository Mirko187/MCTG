package at.technikum.apps.mtcg.user;

import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.SQLException;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserControllerTest {

    @InjectMocks
    UserController userController;

    @Mock
    UserService userService;

    @BeforeEach
    public void setUp() {
        userController = new UserController(userService);
    }

    @Test
    public void createUser_Success() throws SQLException {
        User user = new User("John", "Doe");
        String jsonRequestBody = "{ \"username\": \"John\", \"password\": \"Doe\" }";

        when(userService.createUser(any(User.class))).thenReturn(new User(1L, "John", "Doe"));

        Request request = new Request("GET","/users", "http://localhost");
        request.setBody(jsonRequestBody);

        Response response = userController.createUser(request);

        verify(userService, times(1)).createUser(any(User.class));
        assertEquals(HttpStatus.OK, response.getStatus());
        assertEquals("Success", response.getBody());
    }

    @Test
    public void createUser_Failure() throws SQLException {
        User user = new User("John", "Doe");
        String jsonRequestBody = "{ \"username\": \"John\", \"password\": \"Doe\" }";

        when(userService.createUser(any(User.class))).thenReturn(new User((int) -1L));

        Request request = new Request("GET","/users", "http://localhost");
        request.setBody(jsonRequestBody);

        Response response = userController.createUser(request);

        verify(userService, times(1)).createUser(any(User.class));
        assertEquals(HttpStatus.BAD_REQUEST, response.getStatus());
        assertEquals("No Success", response.getBody());
    }

    @Test
    public void getById_Success() {
        long userId = 1L;
        User user = new User(userId, "John", "Doe");

        when(userService.getUserById(userId)).thenReturn(user);

        Request request = new Request("GET","/users/1", "http://localhost");

        Response response = userController.getById(userId);

        verify(userService, times(1)).getUserById(userId);
        assertEquals(HttpStatus.OK, response.getStatus());
        assertEquals("application/json", response.getContentType());
    }
}