package at.technikum.apps.mtcg.user;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.sql.SQLException;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
public class UserServiceTest {

    @InjectMocks
    UserService userService;

    @Mock
    UserDAO userDAO;

    @Test
    public void whenCreateNewUserWithUniqueUsername_ThenUserIsVerified() throws SQLException {
        User user = new User("Thomas", "Tester");

        when(userDAO.getByUsername(any())).thenReturn(Optional.empty());
        userService.createUser(user);

        verify(userDAO, times(1)).save(any());
    }

    @Test
    public void whenGetUserByIdWithValidId_ThenReturnUser() {
        long user_ID = 1L;
        User user = new User("Marko", "Petrovic");

        when(userDAO.getById(user_ID)).thenReturn(Optional.of(user));

        User result = userService.getUserById(user_ID);

        assertEquals(user, result);
    }


    @Test
    public void whenCreateNewUserWithAlreadyUsedUsername_ThenUserIsNotVerified() throws SQLException {
        User user = new User("Thomas", "Tester");

        when(userDAO.getByUsername(any())).thenReturn(Optional.of(new User("Thomas", "Tester")));
        userService.createUser(user);

        verify(userDAO, times(0)).save(any());
    }
}