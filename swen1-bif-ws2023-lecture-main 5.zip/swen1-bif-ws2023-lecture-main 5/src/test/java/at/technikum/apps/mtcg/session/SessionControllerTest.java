package at.technikum.apps.mtcg.session;

import at.technikum.apps.mtcg.session.auth.AuthToken;
import at.technikum.apps.mtcg.user.User;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class SessionControllerTest {

    @InjectMocks
    private SessionController sessionController;

    @Mock
    private SessionService sessionService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testLoginUser_UserNotFound() {
        Request request = new Request("POST", "/sessions", "http://localhost");
        request.setBody("{\"username\": \"nonexistent\", \"password\": \"password\"}");

        when(sessionService.loginUser(any(User.class)))
                .thenReturn(new LoginResponseWrapper(null, false, false));

        Response response = sessionController.loginUser(request);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatus());
        assertEquals("Username not found", response.getBody());
    }

    @Test
    public void testLoginUser_IncorrectPassword() {
        Request request = new Request("POST", "/sessions", "http://localhost");
        request.setBody("{\"username\": \"existing\", \"password\": \"wrongpassword\"}");

        when(sessionService.loginUser(any(User.class)))
                .thenReturn(new LoginResponseWrapper(null, true, false));

        Response response = sessionController.loginUser(request);

        assertEquals(HttpStatus.UNAUTHORIZED, response.getStatus());
        assertEquals("Incorrect password", response.getBody());
    }

    @Test
    public void testLoginUser_Success() throws Exception {
        Request request = new Request("POST", "/sessions", "http://localhost");
        User user = new User("existing", "correctpassword");
        request.setBody(new ObjectMapper().writeValueAsString(user));

        String authToken = "some-auth-token";
        when(sessionService.loginUser(any(User.class)))
                .thenReturn(new LoginResponseWrapper(new AuthToken(authToken), true, true));

        Response response = sessionController.loginUser(request);

        assertEquals(HttpStatus.OK, response.getStatus());
    }
}
