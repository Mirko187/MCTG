package battle;

import at.technikum.apps.mtcg.session.auth.AuthTokenService;
import at.technikum.apps.mtcg.battle.BattleController;
import at.technikum.apps.mtcg.battle.queue.QueueService;
import at.technikum.apps.mtcg.user.User;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

public class BattleControllerTest {

    @InjectMocks
    private BattleController battleController;

    @Mock
    private QueueService queueService;

    @Mock
    private AuthTokenService authTokenService;

    public BattleControllerTest() {
        MockitoAnnotations.initMocks(this);
    }

    @Test
    public void testQueueForBattle() {
        Request request = new Request("POST", "/battles", "http://localhost");
        String authToken = "sample-auth-token";
        request.setAuthorization(authToken);

        String queueResult = "Successfully queued for battle";
        when(queueService.joinQueue(any(User.class))).thenReturn(queueResult);

        Response response = battleController.queueForBattle(request);

        assertEquals(HttpStatus.OK, response.getStatus());
        assertEquals(queueResult, response.getBody());
    }
}
