package at.technikum.server;

import at.technikum.server.http.Request;
import at.technikum.server.http.Response;

import java.sql.SQLException;

public interface ServerApplication {

    Response handle(Request request) throws SQLException;
}
