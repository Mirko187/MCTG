package at.technikum.apps.mtcg.battle;

import at.technikum.apps.mtcg.user.User;
import at.technikum.apps.mtcg.user.UserDAO;

public class EloCalculator {
    private final UserDAO userDAO;

    private static final int DEFAULT_K_FACTOR = 32;

    public EloCalculator(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    private double calculateExpectedScore(int playerRating, int opponentRating) {
        return 1.0 / (1 + Math.pow(10, (opponentRating - playerRating) / 400.0));
    }

    public void updateElo(User winner, User loser) {
        double winnerExpectedScore = calculateExpectedScore(winner.getElo(), loser.getElo());
        double loserExpectedScore = calculateExpectedScore(loser.getElo(), winner.getElo());


        int winnerNewElo = (int) Math.round(winner.getElo() + DEFAULT_K_FACTOR * (1 - winnerExpectedScore));
        int loserNewElo = (int) Math.round(loser.getElo() + DEFAULT_K_FACTOR * (0 - loserExpectedScore));


        userDAO.updateElo(winner, winnerNewElo);
        userDAO.updateElo(loser, loserNewElo);
    }
}