package at.technikum.apps.mtcg.interfaces;

import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public interface DAO<T> {
    Optional<T> getById(long id);
    List<T> getAll();
    void save(T t) throws SQLException;
    void delete(T t);
    void update(T t);

}
