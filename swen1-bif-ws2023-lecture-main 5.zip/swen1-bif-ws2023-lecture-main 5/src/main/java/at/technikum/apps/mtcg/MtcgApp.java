package at.technikum.apps.mtcg;

import at.technikum.apps.mtcg.battle.BattleController;
import at.technikum.apps.mtcg.battle.BattleService;
import at.technikum.apps.mtcg.battle.EloCalculator;
import at.technikum.apps.mtcg.battle.queue.QueueService;
import at.technikum.apps.mtcg.card.CardDAO;
import at.technikum.apps.mtcg.card.CardService;
import at.technikum.apps.mtcg.casino.CasinoController;
import at.technikum.apps.mtcg.casino.CasinoService;
import at.technikum.apps.mtcg.deck.DeckController;
import at.technikum.apps.mtcg.deck.DeckDAO;
import at.technikum.apps.mtcg.deck.DeckService;
import at.technikum.apps.mtcg.interfaces.AbstractController;
import at.technikum.apps.mtcg.pack.PackageController;
import at.technikum.apps.mtcg.pack.PackageDAO;
import at.technikum.apps.mtcg.pack.PackageService;
import at.technikum.apps.mtcg.persistance.PostgresDatabase;
import at.technikum.apps.mtcg.scoreboard.ScoreboardController;
import at.technikum.apps.mtcg.scoreboard.ScoreboardService;
import at.technikum.apps.mtcg.session.SessionController;
import at.technikum.apps.mtcg.session.SessionService;
import at.technikum.apps.mtcg.stats.StatsController;
import at.technikum.apps.mtcg.stats.StatsService;
import at.technikum.apps.mtcg.transaction.TransactionController;
import at.technikum.apps.mtcg.transaction.TransactionService;
import at.technikum.apps.mtcg.user.UserController;
import at.technikum.apps.mtcg.user.UserDAO;
import at.technikum.apps.mtcg.user.UserService;
import at.technikum.server.ServerApplication;
import at.technikum.server.http.HttpContentType;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class MtcgApp implements ServerApplication {

    private List<AbstractController> controllers = new ArrayList<>();

    //Dependency Injections
    public MtcgApp() {
        controllers.add(new UserController(new UserService(new UserDAO(new PostgresDatabase()))));
        controllers.add(new SessionController(new SessionService(new UserDAO(new PostgresDatabase()))));
        controllers.add(new PackageController(new SessionService(new UserDAO(new PostgresDatabase())), new PackageService(new CardService(new CardDAO(new PostgresDatabase())), new PackageDAO(new PostgresDatabase()), new UserService(new UserDAO(new PostgresDatabase()))), new CardService(new CardDAO(new PostgresDatabase()))));
        controllers.add(new TransactionController(new SessionService(new UserDAO(new PostgresDatabase())), new TransactionService(new UserService(new UserDAO(new PostgresDatabase())), new PackageService(new CardService(new CardDAO(new PostgresDatabase())), new PackageDAO(new PostgresDatabase()), new UserService(new UserDAO(new PostgresDatabase()))))));
        controllers.add(new CasinoController(new SessionService(new UserDAO(new PostgresDatabase())), new CasinoService(new UserService(new UserDAO(new PostgresDatabase())))));
        controllers.add(new BattleController(new SessionService(new UserDAO(new PostgresDatabase())), new QueueService(new PostgresDatabase(), new UserDAO(new PostgresDatabase()), new BattleService(new EloCalculator(new UserDAO(new PostgresDatabase())), new DeckDAO(new PostgresDatabase(), new CardDAO(new PostgresDatabase())), new UserService(new UserDAO(new PostgresDatabase()))))));
        controllers.add(new DeckController(new DeckService(new DeckDAO(new PostgresDatabase(), new CardDAO(new PostgresDatabase())))));
        controllers.add(new StatsController(new SessionService(new UserDAO(new PostgresDatabase())), new StatsService(new UserDAO(new PostgresDatabase()))));
        controllers.add(new ScoreboardController(new SessionService(new UserDAO(new PostgresDatabase())), new ScoreboardService(new UserDAO(new PostgresDatabase()))));
    }

    @Override
    public Response handle(Request request) throws SQLException {

        for (AbstractController controller: controllers) {
            if (!controller.supports(request.getRoute())) {
                continue;
            }

            return controller.verifyAndHandleRequest(request);
        }

        Response response = new Response();
        response.setStatus(HttpStatus.NOT_FOUND);
        response.setContentType(HttpContentType.TEXT_PLAIN);
        response.setBody("Route " + request.getRoute() + " not found in app!");

        return response;
    }
}
