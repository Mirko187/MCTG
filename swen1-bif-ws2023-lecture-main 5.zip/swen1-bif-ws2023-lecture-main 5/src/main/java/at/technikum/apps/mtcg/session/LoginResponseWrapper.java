package at.technikum.apps.mtcg.session;

import at.technikum.apps.mtcg.session.auth.AuthToken;

public class LoginResponseWrapper {
    private AuthToken authToken;
    private boolean userExists;
    private boolean passwordCorrect;

    public LoginResponseWrapper(AuthToken authToken, boolean userExists, boolean passwordCorrect) {
        this.authToken = authToken;
        this.userExists = userExists;
        this.passwordCorrect = passwordCorrect;
    }

    public AuthToken getAuthToken() {
        return authToken;
    }

    public boolean userExists() {
        return userExists;
    }

    public boolean passwordCorrect() {
        return passwordCorrect;
    }
}
