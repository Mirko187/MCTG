package at.technikum.apps.mtcg.pack;

import at.technikum.apps.mtcg.session.auth.AuthTokenService;
import at.technikum.apps.mtcg.card.Card;
import at.technikum.apps.mtcg.card.CardService;
import at.technikum.apps.mtcg.interfaces.AbstractController;
import at.technikum.apps.mtcg.session.SessionService;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.sql.SQLException;

public class PackageController extends AbstractController {

    private final PackageService packageService;
    private final CardService cardService;

    public PackageController(SessionService sessionService, PackageService packageService, CardService cardService) {
        super(sessionService);
        this.packageService = packageService;
        this.cardService = cardService;
    }

    @Override
    public boolean supports(String route) {
        return route.startsWith("/packages");
    }

    @Override
    public Response handle(Request request) throws SQLException {

        AuthTokenService authTokenService = AuthTokenService.getInstance();

        if (request.getRoute().equals("/packages") && authTokenService.getUserFromToken(request.getAuthorization()).getUsername().equals("admin")) {
            switch (request.getMethod()) {

                case "POST": return createPackage(request);
            }
            return status(HttpStatus.BAD_REQUEST);
        }


        return status(HttpStatus.BAD_REQUEST);
    }

    public Response createPackage(Request request) {
        ObjectMapper objectMapper = new ObjectMapper();
        Card[] cards;
        try {
            cards = objectMapper.readValue(request.getBody(), Card[].class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        for (int i = 0; i < cards.length; i++) {
            cards[i] = cardService.parseCardName(cards[i]);
        }
        boolean success = packageService.createNewPackage(new Pack(cards, true));
        Response response = new Response();
        if (success) {
            response.setStatus(HttpStatus.OK);
            response.setBody("Success");
        } else {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setBody("No Success");
        }
        return response;
    }
}
