package at.technikum.apps.mtcg.card;

public enum CardType {
    GOBLIN, DRAGON, ELF, KNIGHT, KRAKEN, ORK, WIZARD, SPELL
}
