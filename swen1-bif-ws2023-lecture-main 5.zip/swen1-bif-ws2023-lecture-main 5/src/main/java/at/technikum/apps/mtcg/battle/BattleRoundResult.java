package at.technikum.apps.mtcg.battle;

public enum BattleRoundResult {
    CARD1WIN, CARD2WIN, DRAW
}