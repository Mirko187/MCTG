package at.technikum.apps.mtcg.pack;

import at.technikum.apps.mtcg.card.Card;
import at.technikum.apps.mtcg.interfaces.DAO;
import at.technikum.apps.mtcg.interfaces.Database;
import at.technikum.apps.mtcg.user.User;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class PackageDAO implements DAO<Pack> {

    private final String CREATE_PACKAGE_SQL = "INSERT INTO packages (card1_id2, card2_id2, card3_id2, card4_id2, card5_id2) VALUES (?, ?, ?, ?, ?)";
    private final String FIND_ALL_PACKS = "SELECT * FROM packages ORDER BY package_id ASC";
    private final String MAKE_PACK_UNAVAILABLE = "UPDATE packages SET is_availabe = false WHERE package_id = ?";

    private final Database database;

    public PackageDAO(Database database) {
        this.database = database;
    }

    @Override
    public Optional<Pack> getById(long id) {
        return Optional.empty();
    }

    @Override
    public List<Pack> getAll() {
        try {
            ResultSet result = database.executeQuery(FIND_ALL_PACKS, new String[]{});
            List<Pack> packs = new java.util.ArrayList<>(List.of());
            while (result.next()) {
                Pack pack = new Pack(
                        result.getLong("package_id"),
                        new Card[]{
                                new Card(result.getString("card1_id2")),
                                new Card(result.getString("card2_id2")),
                                new Card(result.getString("card3_id2")),
                                new Card(result.getString("card4_id2")),
                                new Card(result.getString("card5_id2")),
                        }, result.getBoolean("is_availabe"));
                packs.add(pack);
            }
            return packs;
        } catch (SQLException e) {
            return List.of();
        }
    }

    @Override
    public void save(Pack pack) throws SQLException {
        String[] parameters = new String[5];
        int i = 0;
        for (Card c : pack.getCards()) {
            parameters[i] = c.getId2();
            i++;
        }
        int result = database.executeUpdate(CREATE_PACKAGE_SQL, parameters);
        if (result != 1) throw new RuntimeException("Package could not be persisted in database");
    }

    @Override
    public void delete(Pack pack) {

    }

    @Override
    public void update(Pack pack) {

    }

    protected void setUnavailable(Pack pack) {
        try {
            database.executeUpdate(MAKE_PACK_UNAVAILABLE, new String[]{String.valueOf(pack.getId())});
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
}
