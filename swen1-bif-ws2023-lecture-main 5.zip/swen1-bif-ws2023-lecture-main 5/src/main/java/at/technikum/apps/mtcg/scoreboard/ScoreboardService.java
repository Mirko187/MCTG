package at.technikum.apps.mtcg.scoreboard;

import at.technikum.apps.mtcg.user.User;
import at.technikum.apps.mtcg.user.UserDAO;

import java.sql.SQLException;
import java.util.List;

public class ScoreboardService {
    private final UserDAO userDAO;

    public ScoreboardService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    public List<User> getScoreboard() throws SQLException {
        return userDAO.getScoreboard();
    }
}
