package at.technikum.apps.mtcg.user;

import at.technikum.apps.mtcg.card.Card;
import at.technikum.apps.mtcg.deck.Deck;
import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;

import java.sql.Timestamp;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class User {
    private long id;

    @JsonAlias("Username")
    private String username;

    @JsonAlias("Password")
    private String password;
    private Timestamp lastLogin;
    private int coins;
    private int elo;
    private int gamesPlayed;
    private double winRate;
    private int wins;

    public User(long id, int elo) {
        this.id = id;
        this.elo = elo;
    }

    public User(String username, int gamesPlayed, int wins) {
        this.username = username;
        this.gamesPlayed = gamesPlayed;
        this.wins = wins;;
    }

    public List<Deck> getDecks() {
        return decks;
    }

    public void setDecks(List<Deck> decks) {
        this.decks = decks;
    }

    @JsonIgnore
    private List<Deck> decks;


    public User(long id, String username, String password, Timestamp lastLogin) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.lastLogin = lastLogin;
    }

    public User(String username, int elo) {
        this.elo = elo;
        this.username = username;
    }

    public User(long id, String username, String password, Timestamp lastLogin, int coins, int elo, int gamesPlayed, int wins) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.lastLogin = lastLogin;
        this.coins = coins;
        this.elo = elo;
        this.gamesPlayed = gamesPlayed;
        this.wins = wins;
        this.decks = List.of(new Deck(new Card[]{new Card(), new Card(), new Card(), new Card()}));
    }

    public User() {
    }

    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    public User(int id) {
        this.id = id;
    }

    public long getId() {
        return id;
    }
    public User(long userId, String john, String doe) {
        this.id =  userId;
        this.username = john;
        this.password = doe;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public Timestamp getLastLogin() {
        return lastLogin;
    }

    public void setLastLogin(Timestamp lastLogin) {
        this.lastLogin = lastLogin;
    }

    public int getCoins() {
        return coins;
    }

    public void setCoins(int coins) {
        this.coins = coins;
    }

    public int getElo() {
        return elo;
    }

    public void setElo(int elo) {
        this.elo = elo;
    }

    public int getGamesPlayed() {
        return gamesPlayed;
    }

    public void setGamesPlayed(int gamesPlayed) {
        this.gamesPlayed = gamesPlayed;
    }

    public int getWins() {
        return wins;
    }

    public void setWins(int wins) {
        this.wins = wins;
    }

    public void setWinRate(double winRate) {
        this.winRate = winRate;
    }
}
