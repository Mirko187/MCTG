package at.technikum.apps.mtcg.battle;

import at.technikum.apps.mtcg.card.Card;

public class BattleLogEntry {
    private Card card1;
    private Card card2;
    private BattleRoundResult result;

    public Card getCard1() {
        return card1;
    }

    public Card getCard2() {
        return card2;
    }

    public BattleRoundResult getResult() {
        return result;
    }

    public BattleLogEntry(Card card1, Card card2, BattleRoundResult result) {
        this.card1 = card1;
        this.card2 = card2;
        this.result = result;
    }
}
