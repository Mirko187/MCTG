package at.technikum.apps.mtcg.card;

import com.fasterxml.jackson.annotation.JsonProperty;

public class Card {
    private long id;

    @JsonProperty("Id")
    private String id2;

    @JsonProperty("Name")
    private String name;

    @JsonProperty("Damage")
    private int damage;
    private int wins;

    private int rounds;
    private CardElement element;
    private CardType type;

    public Card(String id2) {
        this.id2 = id2;
    }

    public Card() {
    }

    public Card(long id, String id2, String name, int damage, int rounds, int wins, CardElement element, CardType type) {
        this.id = id;
        this.id2 = id2;
        this.name = name;
        this.damage = damage;
        this.rounds = rounds;
        this.wins = wins;
        this.element = element;
        this.type = type;
    }

    public int getDamage() {
        return damage;
    }

    public void setDamage(int damage) {
        this.damage = damage;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getId2() {
        return id2;
    }

    public void setId2(String id2) {
        this.id2 = id2;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getRounds() {
        return rounds;
    }

    public void setRounds(int rounds) {
        this.rounds = rounds;
    }

    public CardElement getElement() {
        return element;
    }

    public void setElement(CardElement element) {
        this.element = element;
    }

    public CardType getType() {
        return type;
    }

    public void setType(CardType type) {
        this.type = type;
    }
}
