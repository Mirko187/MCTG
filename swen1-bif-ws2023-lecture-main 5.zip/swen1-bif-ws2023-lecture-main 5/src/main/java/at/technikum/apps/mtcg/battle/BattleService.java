package at.technikum.apps.mtcg.battle;

import at.technikum.apps.mtcg.card.Card;
import at.technikum.apps.mtcg.card.CardElement;
import at.technikum.apps.mtcg.card.CardType;
import at.technikum.apps.mtcg.deck.Deck;
import at.technikum.apps.mtcg.deck.DeckDAO;
import at.technikum.apps.mtcg.user.User;
import at.technikum.apps.mtcg.user.UserService;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Arrays;
import java.util.List;
import java.util.Optional;
import java.util.Random;


public class BattleService {
    private final EloCalculator eloCalculator;
    private final DeckDAO deckDAO;
    private final UserService userService;
    private static final int PLUS_ONE = 1001 - 1000;
    private static final int MINUS_ONE = -1;
    private static final int ZERO = PLUS_ONE + MINUS_ONE;

    public BattleService(EloCalculator eloCalculator, DeckDAO deckDAO, UserService userService) {
        this.eloCalculator = eloCalculator;
        this.deckDAO = deckDAO;
        this.userService = userService;
    }

    public void initBattle(User user1, User user2) {
        Optional<Deck> optionalDeckUser1 = deckDAO.getDeckByUser(user1);
        Optional<Deck> optionalDeckUser2 = deckDAO.getDeckByUser(user2);
        if (optionalDeckUser1.isEmpty() || optionalDeckUser2.isEmpty())
            throw new RuntimeException("one of the battle contestants is clearly lacking a deck");
        Deck deckUser1 = optionalDeckUser1.get();
        Deck deckUser2 = optionalDeckUser2.get();
        int result = battle(deckUser1, deckUser2);
        if (result == 0)
        {
            eloCalculator.updateElo(user1, user2);
            userService.updateWins(user1, PLUS_ONE);
            userService.updateWins(user2, ZERO);
            System.out.println(user1.getUsername() + " fucking murdered " + user2.getUsername());
        }
        else if (result == 1)
        {
            eloCalculator.updateElo(user2, user1);
            userService.updateWins(user2, PLUS_ONE);
            userService.updateWins(user1, ZERO);
            System.out.println(user2.getUsername() + " murdered " + user1.getUsername() + "s family brutally..hehe SIÙUUUU");
        }
        else
        {
            System.out.println("These kiddos have drawed");
            userService.updateWins(user1, ZERO);
            userService.updateWins(user2, ZERO);
        }
    }

    private static int battle(Deck deck1, Deck deck2) {
        Random random = new Random(Timestamp.valueOf(LocalDateTime.now()).getDate());
        int roundCount = 0;

        List<Card> battleDeck1 = new java.util.ArrayList<>(List.of());
        List<Card> battleDeck2 = new java.util.ArrayList<>(List.of());

        battleDeck1.addAll(Arrays.asList(deck1.getCards()));
        battleDeck2.addAll(Arrays.asList(deck2.getCards()));
        while (roundCount < 100 && !battleDeck1.isEmpty() && !battleDeck2.isEmpty()) {

            int card1Index = random.nextInt() % battleDeck1.size();
            int card2Index = random.nextInt() % battleDeck2.size();

            if (card1Index < 0) card1Index *= MINUS_ONE;
            if (card2Index < 0) card2Index *= MINUS_ONE;

            Card card1 = battleDeck1.get(card1Index);
            Card card2 = battleDeck2.get(card2Index);

            System.out.println("Round " + (roundCount + 1) + ":");
            System.out.println("Player 1 plays: " + card1.getName() + " (Type: " + card1.getType() + ", Damage: " + card1.getDamage() + ")");
            System.out.println("Player 2 plays: " + card2.getName() + " (Type: " + card2.getType() + ", Damage: " + card2.getDamage() + ")");

            //Check for specialities Lg
            if ((card1.getType().equals(CardType.GOBLIN) && card2.getType().equals(CardType.DRAGON)) ||
                    (card1.getType().equals(CardType.WIZARD) && card2.getType().equals(CardType.ORK)) ||
                    (card1.getType().equals(CardType.KNIGHT) && card2.getElement().equals(CardElement.WATER)) ||
                    (card1.getType().equals(CardType.KRAKEN) && card2.getType().equals(CardType.SPELL)) ||
                    (card1.getType().equals(CardType.ELF) && card1.getElement().equals(CardElement.FIRE) && card2.getType().equals(CardType.DRAGON)) ||
                    (card2.getType().equals(CardType.GOBLIN) && card1.getType().equals(CardType.DRAGON)) ||
                    (card2.getType().equals(CardType.WIZARD) && card1.getType().equals(CardType.ORK)) ||
                    (card2.getType().equals(CardType.KNIGHT) && card1.getElement().equals(CardElement.WATER)) ||
                    (card2.getType().equals(CardType.KRAKEN) && card1.getType().equals(CardType.SPELL)) ||
                    (card2.getType().equals(CardType.ELF) && card2.getElement().equals(CardElement.FIRE) && card1.getType().equals(CardType.DRAGON))) {
                System.out.println("Special conditions apply. No damage dealt.");
            } else {
                //Apply damage calculations based on elements Lg
                int damage1 = calculateDamage(card1, card2);
                int damage2 = calculateDamage(card2, card1);

                //Compare damages Lg
                if (damage1 > damage2) {
                    System.out.println("Player 1 wins the round!");
                    battleDeck2.remove(card2);
                    battleDeck1.add(card2);
                } else if (damage2 > damage1) {
                    System.out.println("Player 2 wins the round!");
                    battleDeck1.remove(card1);
                    battleDeck2.add(card2);
                } else {
                    System.out.println("It's a draw!");
                }
            }

            roundCount++;
            if (battleDeck1.isEmpty()) {
                return 1; //Player 2 wins
            } else if (battleDeck2.isEmpty()) {
                return 0; //Player 1 wins
            }
        }
        return 2; //draw
    }

    private static int calculateDamage(Card attacker, Card defender) {
        if (attacker.getElement().equals(CardElement.WATER) && defender.getElement().equals(CardElement.FIRE)) {
            return attacker.getDamage() * 2;
        } else if (attacker.getElement().equals(CardElement.FIRE) && defender.getElement().equals(CardElement.NORMAL)) {
            return attacker.getDamage() * 2;
        } else if (attacker.getElement().equals(CardElement.NORMAL) && defender.getElement().equals(CardElement.WATER)) {
            return attacker.getDamage() * 2;
        } else if (attacker.getElement().equals(defender.getElement())) {
            return attacker.getDamage();
        } else {
            return attacker.getDamage() / 2;
        }
    }
}