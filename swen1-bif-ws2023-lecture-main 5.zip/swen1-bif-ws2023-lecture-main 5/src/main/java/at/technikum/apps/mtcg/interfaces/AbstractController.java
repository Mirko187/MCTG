package at.technikum.apps.mtcg.interfaces;

import at.technikum.apps.mtcg.session.SessionService;
import at.technikum.server.http.HttpContentType;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;

import java.sql.SQLException;

public abstract class AbstractController {

    protected final SessionService sessionService;

    protected AbstractController(SessionService sessionService) {
        this.sessionService = sessionService;
    }

    public abstract boolean supports(String route);

    public abstract Response handle(Request request) throws SQLException;

    public Response verifyAndHandleRequest(Request request) throws SQLException {
        if ((request.getRoute().equals("/users") && request.getMethod().equalsIgnoreCase("POST"))
                || request.getRoute().equals("/sessions")) {
            return handle(request);
        }
        if (!sessionService.verifyUserLoggedIn(request.getAuthorization())) {
            Response response = new Response();
            response.setStatus(HttpStatus.UNAUTHORIZED);
            response.setBody("Token missing or invalid");
            return response;
        }
        return handle(request);
    }

    public Response status(HttpStatus httpStatus) {
        Response response = new Response();
        response.setStatus(httpStatus);
        response.setContentType(HttpContentType.APPLICATION_JSON);
        response.setBody("{ \"error\": \""+ httpStatus.getMessage() + "\"}");

        return response;
    }
}
