package at.technikum.apps.mtcg.pack;

import at.technikum.apps.mtcg.card.Card;

public class Pack {

    private long id;
    private Card[] cards;

    private Boolean isAvailable;

    public Pack(Card[] cards, Boolean isAvailable) {
        this.cards = cards;
        this.isAvailable = isAvailable;
    }

    public Pack(long id, Card[] cards, Boolean isAvailable) {
        this.id = id;
        this.cards = cards;
        this.isAvailable = isAvailable;
    }

    public Pack() {
        this.id = -1;
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public Boolean getAvailable() {
        return isAvailable;
    }

    public void setAvailable(Boolean available) {
        isAvailable = available;
    }

    public Card[] getCards() {
        return cards;
    }

    public void setCards(Card[] cards) {
        this.cards = cards;
    }
}
