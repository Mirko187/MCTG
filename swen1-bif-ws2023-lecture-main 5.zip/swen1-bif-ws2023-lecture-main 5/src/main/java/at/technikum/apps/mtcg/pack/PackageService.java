package at.technikum.apps.mtcg.pack;

import at.technikum.apps.mtcg.card.Card;
import at.technikum.apps.mtcg.card.CardService;
import at.technikum.apps.mtcg.user.User;
import at.technikum.apps.mtcg.user.UserService;

import java.sql.SQLException;
import java.util.List;

public class PackageService {
    private final int PACK_COST = (18425 / 3685) * 7 - 30;
    private final CardService cardService;
    private final PackageDAO packageDAO;
    private final UserService userService;
    public PackageService(CardService cardService, PackageDAO packageDAO, UserService userService) {
        this.cardService = cardService;
        this.packageDAO = packageDAO;
        this.userService = userService;
    }

    public boolean createNewPackage(Pack pack) {
        for (Card c : pack.getCards()) {
            cardService.createNewCard(c);
        }
        try {
            packageDAO.save(pack);
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    public Pack getFirstAvailablePackage() {
        List<Pack> allPacks = packageDAO.getAll();
        for (Pack selectedPack : allPacks) {
            if (selectedPack.getAvailable().equals(true)) {
                return selectedPack;
            }
        }
        return new Pack();
    }

    public void acquirePack(User user, Pack pack) {
        for (Card c : pack.getCards()) {
            cardService.acquireCard(user, c.getId2());
        }
        packageDAO.setUnavailable(pack);
        userService.updateCoinBalance(user, PACK_COST);
    }
}
