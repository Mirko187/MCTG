package at.technikum.apps.mtcg.card;

import at.technikum.apps.mtcg.interfaces.DAO;
import at.technikum.apps.mtcg.interfaces.Database;
import at.technikum.apps.mtcg.user.User;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class CardDAO implements DAO<Card> {

    private final String CREATE_CARD_SQL = "INSERT INTO cards (name, card_id2, card_damage, element, type) VALUES (?, ?, ?, ?, ?)";
    private final String EXCHANGE_IDS_SQL = "SELECT card_id FROM cards WHERE card_id2 = ?";
    private final String CREATE_OWNERSHIT = "INSERT INTO ownership (owner_id, date_start, card_id) VALUES (?, now(), ?)";
    private final String FIND_BY_ID_SQL = "SELECT * FROM cards where card_id = ?";

    private final Database database;

    public CardDAO(Database database) {
        this.database = database;
    }

    @Override
    public Optional<Card> getById(long id) {
        try {
            String[] parameters = new String[] {String.valueOf(id)};
            return extractOptionalCardFromResultSet(parameters, FIND_BY_ID_SQL);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<Card> getAll() {
        return null;
    }

    @Override
    public void save(Card card) throws SQLException {
        String[] parameters = new String[] {
                card.getName(),
                card.getId2(),
                String.valueOf(card.getDamage()),
                card.getElement().toString(),
                card.getType().toString()};
        int result = database.executeUpdate(CREATE_CARD_SQL, parameters);
        if (result != 1) throw new RuntimeException("Card could not be persisted in database");
    }

    @Override
    public void delete(Card card) {

    }

    @Override
    public void update(Card card) {

    }

    public int exchangeIds(String id2) {
        try {
            ResultSet results = database.executeQuery(EXCHANGE_IDS_SQL, new String[]{id2});
            if (results.next()) {
                return results.getInt("card_id");
            } else {
                return -1;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    protected void establishOwnership(User user, Card card) {
        try {
            database.executeUpdate(CREATE_OWNERSHIT, new String[]{String.valueOf(user.getId()), String.valueOf(card.getId())});
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private Optional<Card> extractOptionalCardFromResultSet(String[] parameters, String sql) throws SQLException
    {
        ResultSet results = database.executeQuery(sql, parameters);
        if (results.next()) {
            Card card = new Card(
                    Long.valueOf(results.getInt("card_id")),
                    results.getString("card_id2"),
                    results.getString("name"),
                    results.getInt("card_damage"),
                    results.getInt("card_rounds"),
                    results.getInt("card_wins"),
                    CardElement.valueOf(results.getString("element")),
                    CardType.valueOf(results.getString("type"))
            );
            return Optional.of(card);
        } else {
            return Optional.empty();
        }
    }
}
