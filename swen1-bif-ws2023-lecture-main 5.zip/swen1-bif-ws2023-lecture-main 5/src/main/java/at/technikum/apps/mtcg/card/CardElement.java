package at.technikum.apps.mtcg.card;

public enum CardElement {
    WATER, FIRE, NORMAL
}
