package at.technikum.apps.mtcg.session;

import at.technikum.apps.mtcg.interfaces.AbstractController;
import at.technikum.apps.mtcg.persistance.PostgresDatabase;
import at.technikum.apps.mtcg.user.User;
import at.technikum.apps.mtcg.user.UserDAO;
import at.technikum.server.http.HttpContentType;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.sql.SQLException;

public class SessionController extends AbstractController {

    private final SessionService sessionService;

    public SessionController(SessionService sessionService) {
        super(new SessionService(new UserDAO(new PostgresDatabase())));
        this.sessionService = sessionService;
    }

    @Override
    public boolean supports(String route) {
        return route.startsWith("/sessions");
    }

    @Override
    public Response handle(Request request) throws SQLException {

        if (request.getRoute().equals("/sessions")) {
            switch (request.getMethod()) {
                //case "GET": return readAll(request);
                case "POST": return loginUser(request);
            }

            return status(HttpStatus.BAD_REQUEST);
        }

        // THOUGHT: better 405
        return status(HttpStatus.BAD_REQUEST);
    }

    public Response loginUser(Request request) {
        ObjectMapper objectMapper = new ObjectMapper();
        User user;
        try {
            user = objectMapper.readValue(request.getBody(), User.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        LoginResponseWrapper loginResponse = sessionService.loginUser(user);
        Response response = new Response();

        if (!loginResponse.userExists()) {
            response.setStatus(HttpStatus.UNAUTHORIZED);
            response.setBody("Username not found");
            return response;
        }
        if (!loginResponse.passwordCorrect()) {
            response.setStatus(HttpStatus.UNAUTHORIZED);
            response.setBody("Incorrect password");
            return response;
        }
        response.setStatus(HttpStatus.OK);
        response.setContentType(HttpContentType.APPLICATION_JSON);
        try {
            response.setBody(objectMapper.writeValueAsString(loginResponse.getAuthToken()));
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        return response;
    }
}
