package at.technikum.apps.mtcg.transaction;

import at.technikum.apps.mtcg.pack.Pack;
import at.technikum.apps.mtcg.pack.PackageService;
import at.technikum.apps.mtcg.user.User;
import at.technikum.apps.mtcg.user.UserService;

public class TransactionService {

    private final UserService userService;
    private final PackageService packageService;

    public TransactionService(UserService userService, PackageService packageService) {
        this.userService = userService;
        this.packageService = packageService;
    }

    protected boolean acquirePackage(User user) {
        Pack pack = packageService.getFirstAvailablePackage();
        if (pack.getId() == -1) return false;
        user = userService.getUserById(user.getId());
        if (user.getCoins() < 5) return false;
        packageService.acquirePack(user, pack);
        return true;
    }

}