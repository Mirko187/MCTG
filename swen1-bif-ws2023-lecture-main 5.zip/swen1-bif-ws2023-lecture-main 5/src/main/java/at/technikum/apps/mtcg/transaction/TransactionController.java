package at.technikum.apps.mtcg.transaction;

import at.technikum.apps.mtcg.session.auth.AuthTokenService;
import at.technikum.apps.mtcg.interfaces.AbstractController;
import at.technikum.apps.mtcg.session.SessionService;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;

import java.sql.SQLException;

public class TransactionController extends AbstractController {

    private final TransactionService transactionService;
    public TransactionController(SessionService sessionService, TransactionService transactionService) {
        super(sessionService);
        this.transactionService = transactionService;
    }

    @Override
    public boolean supports(String route) {
        return route.startsWith("/transactions");
    }

    @Override
    public Response handle(Request request) throws SQLException {

        // ToDo: cleanup
        //if (request.getRoute().equals("/users")) {
        //    switch (request.getMethod()) {
        //        //case "GET": return readAll(request);
        //        case "POST": return createUser(request);
        //    }
//
        //    return status(HttpStatus.BAD_REQUEST);
        //}

        String[] routeParts = request.getRoute().split("/");
        if (routeParts[2].equals("packages")) {
            switch (request.getMethod()) {
                case "POST": return acquirePackage(request);
                //case "PUT": return update(taskId, request);
                //case "DELETE": return delete(taskId, request);
            }
        }
        // THOUGHT: better 405
        return status(HttpStatus.BAD_REQUEST);
    }

    public Response acquirePackage(Request request) {
        AuthTokenService authTokenService = AuthTokenService.getInstance();
        boolean success = transactionService.acquirePackage(authTokenService.getUserFromToken(request.getAuthorization()));
        Response response = new Response();
        if (success) {
            response.setStatus(HttpStatus.OK);
            response.setBody("Success");
        } else {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setBody("No Success");
        }
        return response;
    }
}
