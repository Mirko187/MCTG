package at.technikum.apps.mtcg.session.auth;

import at.technikum.apps.mtcg.user.User;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.HashSet;
import java.util.Set;

public final class AuthTokenService {

    private static AuthTokenService INSTANCE;
    private Set<AuthToken> tokens;

    private AuthTokenService() {
        tokens = new HashSet<AuthToken>();
    }

    public static AuthTokenService getInstance() {
        if(INSTANCE == null) {
            INSTANCE = new AuthTokenService();
        }
        return INSTANCE;
    }

    public AuthToken createToken(User user) {
        AuthToken token = new AuthToken(user);
        tokens.add(token);
        return token;
    }

    //check if token is in time
    public boolean verifyAuthToken(String token) {
        for (AuthToken t : tokens) {
            if (t.getToken().equals(token)) {
                if (t.getValidFrom().before(Timestamp.valueOf(LocalDateTime.now())) && t.getValidTo().after(Timestamp.valueOf(LocalDateTime.now()))) {
                    return true;
                }
                tokens.remove(t);
                return false;
            }
        }
        return false;
    }

    public User getUserFromToken(String token) {
        for (AuthToken t : tokens) {
            if (t.getToken().equals(token.split(" ")[1])) {
                if (t.getValidFrom().before(Timestamp.valueOf(LocalDateTime.now())) && t.getValidTo().after(Timestamp.valueOf(LocalDateTime.now()))) {
                    return t.getUser();
                }
                return new User(-1);
            }
        }
        return new User(-1);
    }
}
