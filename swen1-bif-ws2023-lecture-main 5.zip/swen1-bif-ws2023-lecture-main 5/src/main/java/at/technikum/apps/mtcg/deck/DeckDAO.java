package at.technikum.apps.mtcg.deck;

import at.technikum.apps.mtcg.card.Card;
import at.technikum.apps.mtcg.card.CardDAO;
import at.technikum.apps.mtcg.interfaces.DAO;
import at.technikum.apps.mtcg.interfaces.Database;
import at.technikum.apps.mtcg.user.User;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.List;
import java.util.Optional;

public class DeckDAO implements DAO<Deck> {
    private final Database database;
    private final CardDAO cardDAO;

    private final String GET_DECK_BY_USER_SQL = "SELECT * FROM decks WHERE user_id = ?";
    private final String INSERT_DECK_SQL = "INSERT INTO decks(card1_id2, card2_id2, card3_id2, card4_id2, user_id) VALUES (?, ?, ?, ?, ?)";

    public DeckDAO(Database database, CardDAO cardDAO) {
        this.database = database;
        this.cardDAO = cardDAO;
    }

    @Override
    public Optional<Deck> getById(long id) {
        return Optional.empty();
    }

    @Override
    public List<Deck> getAll() {
        return null;
    }

    @Override
    public void save(Deck deck) throws SQLException {

    }

    @Override
    public void delete(Deck deck) {

    }

    @Override
    public void update(Deck deck) {

    }

    public Optional<Deck> getDeckByUser(User user) {
        try {
            String[] parameters = new String[] {String.valueOf(user.getId())};
            return extractOptionalDeckFromResultSet(parameters, GET_DECK_BY_USER_SQL);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void createDeck(String card1, String card2, String card3, String card4, User user) {
        try {
            String[] parameters = new String[] {card1, card2, card3, card4, String.valueOf(user.getId())};
            int result = database.executeUpdate(INSERT_DECK_SQL, parameters);
            if (result != 1) throw new RuntimeException("Deck could not be persisted in database");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private Optional<Deck> extractOptionalDeckFromResultSet(String[] parameters, String sql) throws SQLException {
        ResultSet results = database.executeQuery(sql, parameters);
        if (results.next()) {
            Card[] cards = new Card[4];
            cards[0] = cardDAO.getById(cardDAO.exchangeIds(results.getString("card1_id2"))).get();
            cards[1] = cardDAO.getById(cardDAO.exchangeIds(results.getString("card2_id2"))).get();
            cards[2] = cardDAO.getById(cardDAO.exchangeIds(results.getString("card3_id2"))).get();
            cards[3] = cardDAO.getById(cardDAO.exchangeIds(results.getString("card4_id2"))).get();
            Deck deck = new Deck(cards);
            return Optional.of(deck);
        } else {
            return Optional.empty();
        }
    }
}
