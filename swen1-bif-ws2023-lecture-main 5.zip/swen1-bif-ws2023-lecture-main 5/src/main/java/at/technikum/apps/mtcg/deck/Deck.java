package at.technikum.apps.mtcg.deck;

import at.technikum.apps.mtcg.card.Card;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Random;


public class Deck {
    private int id;
    private Card[] cards;
    public Deck(Card[] cards) {
        this.cards = cards;
    }
    public Card[] getCards() {
        return this.cards;
    }
}
