package at.technikum.apps.mtcg.battle.queue;

import at.technikum.apps.mtcg.battle.BattleService;
import at.technikum.apps.mtcg.interfaces.Database;
import at.technikum.apps.mtcg.user.User;
import at.technikum.apps.mtcg.user.UserDAO;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Optional;

public class QueueService {

    private final String INSERT_INTO_QUEUE_SQL = "INSERT INTO queue (user_id) VALUES (?)";
    private final String GET_QUEUE_SQL = "SELECT * FROM queue";
    private final String CLEAN_QUEUE_SQL = "DELETE FROM queue where user_id = ?";

    private final Database database;
    private final UserDAO userDAO;
    private final BattleService battleService;

    public QueueService(Database database, UserDAO userDAO, BattleService battleService) {
        this.database = database;
        this.userDAO = userDAO;
        this.battleService = battleService;
    }

    public String joinQueue(User user) {
        Optional<User> optionalUser = getFromQueue(user.getId());
        if (optionalUser.isPresent()) {
            if (optionalUser.get().getId() == user.getId())
            {
                return "You are already in queue cracker, chill a bit";
            }
            if (optionalUser.get().getId() != -1) {
                battleService.initBattle(user, optionalUser.get());
                return "Starting battle against " + optionalUser.get().getUsername();
            } else {
                try {
                    database.executeUpdate(INSERT_INTO_QUEUE_SQL, new String[]{String.valueOf(user.getId())});
                    return "You are in queue, chill a bit";
                } catch (SQLException e) {
                    throw new RuntimeException(e);
                }
            }
        }
        throw new RuntimeException("huehuehueheu");
    }

    private Optional<User> getFromQueue(long id) {
        try {
            String[] parameters = new String[] {};
            int iddb = getQueue(parameters, GET_QUEUE_SQL);
            if (iddb == -1) {
                database.executeUpdate(INSERT_INTO_QUEUE_SQL, new String[]{String.valueOf(id)});
            } else {
                Optional<User> optionalUser = userDAO.getById(iddb);
                database.executeUpdate(CLEAN_QUEUE_SQL, new String[]{String.valueOf(iddb)});
                return optionalUser;
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return Optional.of(new User(-1));
    }

    private int getQueue(String[] parameters, String sql) throws SQLException {
        ResultSet results = database.executeQuery(sql, parameters);
        if (results.next()) {
            return results.getInt("user_id");
        } else {
            return -1;
        }
    }
}
