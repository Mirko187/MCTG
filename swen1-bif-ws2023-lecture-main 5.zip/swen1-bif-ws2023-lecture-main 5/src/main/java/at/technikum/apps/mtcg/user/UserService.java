package at.technikum.apps.mtcg.user;

import at.technikum.apps.mtcg.exception.UserNotFoundException;
import at.technikum.apps.mtcg.interfaces.DAO;

import java.sql.SQLException;
import java.util.Optional;

public class UserService {

    public UserService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    private UserDAO userDAO;

    public User getUserById(long id) {
        Optional<User> userOptional = userDAO.getById(id);
        return userOptional.orElseThrow();
    }

    public User createUser(User user) throws SQLException {
        if (verifyNewUser(user)) {
            userDAO.save(user);
            return new User();
        } else {
            return new User(-1);
        }
    }

    public void updateWins(User user, int plusWins) {
        userDAO.updateWins(user, plusWins);
    }

    private boolean verifyNewUser(User user) {
        Optional<User> userOptional = userDAO.getByUsername(user.getUsername());
        if (userOptional.isEmpty()) {
            return true;
        } else {
            return false;
        }
    }

    public void updateCoinBalance(User user, int difference) {
        userDAO.updateBalance(user, difference);
    }
}
