package at.technikum.apps.mtcg.battle;

import at.technikum.apps.mtcg.card.Card;
import at.technikum.apps.mtcg.user.User;

import java.time.LocalDateTime;
import java.util.List;
public class BattleLog {
    private LocalDateTime dateTime;
    private User player1;
    private User player2;
    private List<BattleLogEntry> log;

    public BattleLog(User player1, User player2) {
        this.player1 = player1;
        this.player2 = player2;
        this.dateTime = LocalDateTime.now();
    }

    public LocalDateTime getDateTime() {
        return dateTime;
    }

    public User getPlayer1() {
        return player1;
    }

    public User getPlayer2() {
        return player2;
    }

    public List<BattleLogEntry> getLog() {
        return log;
    }

    public void setLog(List<BattleLogEntry> log) {
        this.log = log;
    }

    public void addEntry(Card card1, Card card2, BattleRoundResult result) {
        log.add(new BattleLogEntry(card1, card2, result));
    }
}
