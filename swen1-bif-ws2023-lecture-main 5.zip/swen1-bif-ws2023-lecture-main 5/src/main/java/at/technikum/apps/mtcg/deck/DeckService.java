package at.technikum.apps.mtcg.deck;

import at.technikum.apps.mtcg.user.User;

import java.util.Optional;

public class DeckService {

    private final DeckDAO deckDAO;

    public DeckService(DeckDAO deckDAO) {
        this.deckDAO = deckDAO;
    }

    protected Optional<Deck> getDeckIfExistsByUser(User user) {
        return deckDAO.getDeckByUser(user);
    }

    protected void createDeck(String card1, String card2, String card3, String card4, User user) {
        deckDAO.createDeck(card1, card2, card3, card4, user);
    }
}
