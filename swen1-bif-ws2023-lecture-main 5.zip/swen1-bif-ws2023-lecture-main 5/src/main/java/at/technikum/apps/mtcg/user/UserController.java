package at.technikum.apps.mtcg.user;

import at.technikum.apps.mtcg.interfaces.AbstractController;
import at.technikum.apps.mtcg.persistance.PostgresDatabase;
import at.technikum.apps.mtcg.session.SessionService;
import at.technikum.server.http.HttpContentType;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.sql.SQLException;

public class UserController extends AbstractController {

    private UserService userService;

    public UserController(UserService userService) {
        super(new SessionService(new UserDAO(new PostgresDatabase())));
        this.userService = userService;
    }

    @Override
    public boolean supports(String route) {
        return route.startsWith("/users");
    }

    @Override
    public Response handle(Request request) throws SQLException {

        if (request.getRoute().equals("/users")) {
            switch (request.getMethod()) {
                //case "GET": return readAll(request);
                case "POST": return createUser(request);
            }

            return status(HttpStatus.BAD_REQUEST);
        }

        String[] routeParts = request.getRoute().split("/");
        long userId;
        try {
            userId = Integer.parseInt(routeParts[2]);
        } catch (ArrayIndexOutOfBoundsException e) {
            throw new RuntimeException(e);
        }

        switch (request.getMethod()) {
            case "GET": return getById(userId);
            //case "PUT": return update(taskId, request);
            //case "DELETE": return delete(taskId, request);
        }

        // THOUGHT: better 405
        return status(HttpStatus.BAD_REQUEST);
    }

    public Response createUser(Request request) throws SQLException {
        ObjectMapper objectMapper = new ObjectMapper();
        User user;
        try {
             user = objectMapper.readValue(request.getBody(), User.class);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        User result = userService.createUser(user);
        Response response = new Response();
        if (result.getId() != -1) {
            response.setStatus(HttpStatus.OK);
            response.setBody("Success");
        } else {
            response.setStatus(HttpStatus.BAD_REQUEST);
            response.setBody("No Success");
        }
        return response;
    }

    public Response getById(Long id) {
        User user = userService.getUserById(id);

        ObjectMapper objectMapper = new ObjectMapper();
        String userJson;
        try {
            userJson = objectMapper.writeValueAsString(user);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        Response response = new Response();
        response.setStatus(HttpStatus.OK);
        response.setContentType(HttpContentType.APPLICATION_JSON);
        response.setBody(userJson);

        return response;
    }

}
