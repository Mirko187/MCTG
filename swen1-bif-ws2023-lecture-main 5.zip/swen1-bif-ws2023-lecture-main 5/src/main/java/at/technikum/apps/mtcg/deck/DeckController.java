package at.technikum.apps.mtcg.deck;

import at.technikum.apps.mtcg.interfaces.AbstractController;
import at.technikum.apps.mtcg.persistance.PostgresDatabase;
import at.technikum.apps.mtcg.session.SessionService;
import at.technikum.apps.mtcg.session.auth.AuthTokenService;
import at.technikum.apps.mtcg.user.UserDAO;
import at.technikum.server.http.HttpContentType;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonMappingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.sql.SQLException;
import java.util.Optional;

public class DeckController extends AbstractController {
    private final DeckService deckService;

    public DeckController(DeckService deckService) {
        super(new SessionService(new UserDAO(new PostgresDatabase())));
        this.deckService = deckService;
    }

    @Override
    public boolean supports(String route) {
        return route.equals("/deck");
    }

    public Response handle(Request request) throws SQLException {

        if (request.getRoute().equals("/deck")) {
            switch (request.getMethod()) {
                case "GET": return getDeck(request);
                case "PUT": return createDeck(request);
            }
        }

        return status(HttpStatus.BAD_REQUEST);
    }

    private Response createDeck(Request request) {
        AuthTokenService authTokenService = AuthTokenService.getInstance();
        ObjectMapper objectMapper = new ObjectMapper();
        String[] cardIds;
        try {
            cardIds = objectMapper.readValue(request.getBody(), String[].class);
        } catch (JsonMappingException e) {
            throw new RuntimeException(e);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
        deckService.createDeck(cardIds[0], cardIds[1], cardIds[2], cardIds[3], authTokenService.getUserFromToken(request.getAuthorization()));
        Response response = new Response();
        response.setStatus(HttpStatus.OK);
        response.setBody("Success");
        return response;
    }

    private Response getDeck(Request request) {
        AuthTokenService authTokenService = AuthTokenService.getInstance();
        Optional<Deck> deck = deckService.getDeckIfExistsByUser(authTokenService.getUserFromToken(request.getAuthorization()));
        ObjectMapper objectMapper = new ObjectMapper();
        String deckJson;
        try {
            deckJson = objectMapper.writeValueAsString(deck.get());
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }

        Response response = new Response();
        response.setStatus(HttpStatus.OK);
        response.setContentType(HttpContentType.APPLICATION_JSON);
        response.setBody(deckJson);

        return response;
    }
}
