package at.technikum.apps.mtcg.persistance;

import at.technikum.apps.mtcg.interfaces.Database;

import java.sql.*;

public class PostgresDatabase implements Database {
    private static final String URL = "jdbc:postgresql://localhost:5432/mctgdb";
    private static final String USERNAME = "postgres";
    private static final String PASSWORD = "postgres";

    private Connection getConnection() throws SQLException {
        return DriverManager.getConnection(URL, USERNAME, PASSWORD);
    }

    @Override
    public ResultSet executeQuery(String query, String[] parameters) throws SQLException {
        PreparedStatement statement = preparePreparedStatement(query, parameters);
        return statement.executeQuery();
    }

    @Override
    public int executeUpdate(String query, String[] parameters) throws SQLException {
        PreparedStatement statement = preparePreparedStatement(query, parameters);
        return statement.executeUpdate();
    }

    private PreparedStatement preparePreparedStatement(String query, String[] parameters) throws SQLException {
        Connection connection = getConnection();
        PreparedStatement statement = connection.prepareStatement(query);

        for (int i = 1; i <= parameters.length; i++) {
            if (isInteger(parameters[i - 1])){
                statement.setInt(i, Integer.parseInt(parameters[i - 1]));
            } else {
                statement.setString(i, parameters[i - 1]);
            }
        }
        return statement;
    }

    public static boolean isInteger(String str) {
        try {
            Integer.parseInt(str);
            return true;
        } catch (NumberFormatException e) {
            return false;
        }
    }
}
