package at.technikum.apps.mtcg.stats;

import at.technikum.apps.mtcg.user.User;
import at.technikum.apps.mtcg.user.UserDAO;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

public class StatsService {
    private final UserDAO userDAO;

    public StatsService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    public User getStats(User user) {
        return userDAO.getUserStatsById(((int) user.getId()));
    }
}
