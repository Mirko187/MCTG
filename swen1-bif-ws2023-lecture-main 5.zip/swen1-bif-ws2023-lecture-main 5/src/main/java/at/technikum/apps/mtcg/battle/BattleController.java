package at.technikum.apps.mtcg.battle;

import at.technikum.apps.mtcg.session.auth.AuthTokenService;
import at.technikum.apps.mtcg.battle.queue.QueueService;
import at.technikum.apps.mtcg.interfaces.AbstractController;
import at.technikum.apps.mtcg.session.SessionService;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;

import java.sql.SQLException;

public class BattleController extends AbstractController {
    private final QueueService queueService;

    public BattleController(SessionService sessionService, QueueService queueService) {
        super(sessionService);
        this.queueService = queueService;
    }

    @Override
    public boolean supports(String route) {
        return route.startsWith("/battles");
    }

    @Override
    public Response handle(Request request) throws SQLException {

        if (request.getRoute().equals("/battles")) {
            switch (request.getMethod()) {

                case "POST": return queueForBattle(request);
            }

            return status(HttpStatus.BAD_REQUEST);
        }


        return status(HttpStatus.BAD_REQUEST);
    }

    public Response queueForBattle(Request request) {
        AuthTokenService authTokenService = AuthTokenService.getInstance(); // Retrieve the singleton instance of AuthTokenService
        String result = queueService.joinQueue(authTokenService.getUserFromToken(request.getAuthorization()));
        Response response = new Response();
        response.setStatus(HttpStatus.OK);
        response.setBody(result);
        return response;
    }
}