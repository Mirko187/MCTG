package at.technikum.apps.mtcg.exception;

public class UserNotFoundException extends Exception{
    public UserNotFoundException(String errorMassage) {
        super(errorMassage);
    }
}
