package at.technikum.apps.mtcg.card;

import at.technikum.apps.mtcg.user.User;

import java.sql.SQLException;
import java.util.Locale;

public class CardService {
    private final CardDAO cardDAO;

    public CardService(CardDAO cardDAO) {
        this.cardDAO = cardDAO;
    }

    public boolean createNewCard(Card card) {
        try {
            cardDAO.save(card);
            return true;
        } catch (SQLException e) {
            return false;
        }
    }

    public void acquireCard(User user, String id2) {
        Card card = cardDAO.getById(cardDAO.exchangeIds(id2)).orElseThrow();
        cardDAO.establishOwnership(user, card);
    }

    public Card parseCardName(Card card) {
        if(card.getName().toLowerCase(Locale.GERMAN).contains("fire")) {
            card.setElement(CardElement.FIRE);
        } else if (card.getName().toLowerCase(Locale.GERMAN).contains("water")) {
            card.setElement(CardElement.WATER);
        } else {
            card.setElement(CardElement.NORMAL);
        }
        if(card.getName().toLowerCase(Locale.GERMAN).contains("dragon")){
            card.setType(CardType.DRAGON);
        } else if(card.getName().toLowerCase(Locale.GERMAN).contains("elf")){
            card.setType(CardType.ELF);
        } else if(card.getName().toLowerCase(Locale.GERMAN).contains("goblin")){
            card.setType(CardType.GOBLIN);
        } else if(card.getName().toLowerCase(Locale.GERMAN).contains("knight")){
            card.setType(CardType.KNIGHT);
        } else if(card.getName().toLowerCase(Locale.GERMAN).contains("kraken")){
            card.setType(CardType.KRAKEN);
        } else if(card.getName().toLowerCase(Locale.GERMAN).contains("ork")){
            card.setType(CardType.ORK);
        } else if(card.getName().toLowerCase(Locale.GERMAN).contains("wizard")){
            card.setType(CardType.WIZARD);
        } else if(card.getName().toLowerCase(Locale.GERMAN).contains("spell")){
            card.setType(CardType.SPELL);
        }
        return card;
    }
}
