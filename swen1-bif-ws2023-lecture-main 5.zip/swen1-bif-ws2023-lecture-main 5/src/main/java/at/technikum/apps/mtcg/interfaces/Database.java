package at.technikum.apps.mtcg.interfaces;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Map;

public interface Database {
    ResultSet executeQuery(String query, String[] parameters) throws SQLException;

    int executeUpdate(String query, String[] parameters) throws SQLException;
}
