package at.technikum.apps.mtcg.session.auth;

import at.technikum.apps.mtcg.user.User;

import java.sql.Timestamp;
import java.time.LocalDateTime;

public class AuthToken {

    private String token;

    private User user;
    private Timestamp validFrom;
    private Timestamp validTo;

    public AuthToken(String token) {
        this.token = token;
    }
    public AuthToken(User user) {
        LocalDateTime dateTimeNow = LocalDateTime.now();
        Timestamp now = Timestamp.valueOf(dateTimeNow);
        Timestamp nowPlus1h = Timestamp.valueOf(dateTimeNow.plusHours(1));
        this.token = user.getUsername() + "-mtcgToken";
        this.user = user;
        this.validFrom = now;
        this.validTo = nowPlus1h;
    }

    public String getToken() {
        return token;
    }

    public Timestamp getValidFrom() {
        return validFrom;
    }

    public Timestamp getValidTo() {
        return validTo;
    }


    public User getUser() {
        return user;
    }
}
