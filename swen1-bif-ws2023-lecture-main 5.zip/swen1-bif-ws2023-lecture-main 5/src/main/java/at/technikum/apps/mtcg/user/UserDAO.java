package at.technikum.apps.mtcg.user;

import at.technikum.apps.mtcg.interfaces.DAO;
import at.technikum.apps.mtcg.interfaces.Database;
import at.technikum.apps.mtcg.persistance.PostgresDatabase;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

public class UserDAO implements DAO<User> {

    private final String FIND_BY_ID_SQL = "SELECT * FROM users u WHERE u.user_id = ?;";
    private final String FIND_BY_USERNAME_SQL = "SELECT * FROM users u WHERE u.username = ?;";
    private final String FIND_ALL_SQL = "SELECT * FROM user";
    private final String CREATE_USER_SQL = "INSERT INTO users (username, password) VALUES (?, ?)";
    private final String UPDATE_USER_BALANCE = "UPDATE users SET coins = coins + ? WHERE user_id = ?";
    private final String UPDATE_USER_ELO = "UPDATE users SET elo = ? WHERE user_id = ?";
    private final String SCOARBOARD_SQL = "SELECT username, elo FROM users ORDER BY elo DESC";
    private final String GET_USERSTATS_SQL = "SELECT username, games_played, wins FROM users WHERE user_id = ?";
    private final String UPDATE_WINS_SQL = "UPDATE users SET games_played = games_played + ?, wins = wins + ? WHERE user_id = ?";
    private final int ONE = 1;

    private final Database database;

    public UserDAO(Database database) {
        this.database = database;
    }

    @Override
    public Optional<User> getById(long id) {
        try {
            String[] parameters = new String[] {String.valueOf(id)};
            return extractOptionalUserFromResultSet(parameters, FIND_BY_ID_SQL);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Optional<User> getByUsername(String username) {
        try {
            String[] parameters = new String[] {username};
            return extractOptionalUserFromResultSet(parameters, FIND_BY_USERNAME_SQL);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<User> getScoreboard() throws SQLException {
        try {
            ResultSet resultSet = database.executeQuery(SCOARBOARD_SQL, new String[]{});

            List<User> scoreboard = new ArrayList<>();

            while (resultSet.next()) {
                String username = resultSet.getString("username");
                int elo = resultSet.getInt("elo");

                User user = new User(username,elo);

                scoreboard.add(user);
            }

            return scoreboard;
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<User> getAll() {
        List<User> userList;
        try {
            ResultSet resultSet = database.executeQuery(FIND_ALL_SQL, new String[]{});
            userList = extractUsersFromResultSet(resultSet);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return userList;
    }

    @Override
    public void save(User user) throws SQLException {
        String[] parameters = new String[] {user.getUsername(), user.getPassword()};
        int result = database.executeUpdate(CREATE_USER_SQL, parameters);
        if (result != 1) throw new RuntimeException("User could not be persisted in database");
    }

    public User getUserStatsById(int id) {
        try {
            ResultSet resultSet = database.executeQuery(GET_USERSTATS_SQL, new String[]{String.valueOf(id)});
            if(resultSet.next()) {
                return new User(resultSet.getString("username"),
                        resultSet.getInt("games_played"),
                        resultSet.getInt("wins"));
            }
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        throw new RuntimeException();
    }

    @Override
    public void delete(User user) {
    }

    @Override
    public void update(User user) {

    }

    protected void updateBalance(User user, int difference) {
        String[] parameters = new String[] {String.valueOf(difference * (-1)), String.valueOf(user.getId())};
        int result;
        try {
            result = database.executeUpdate(UPDATE_USER_BALANCE, parameters);
        } catch (SQLException e) {
            throw new RuntimeException("Unable to update user balance");
        }
        if (result != 1) throw new RuntimeException("Unable to update user balance");
    }

    public void updateElo(User user, int newElo) {
        String[] parameters = new String[] {String.valueOf(newElo), String.valueOf(user.getId())};
        int result;
        try {
            result = database.executeUpdate(UPDATE_USER_ELO, parameters);
        } catch (SQLException e) {
            throw new RuntimeException("Unable to update user elo");
        }
        if (result != 1) throw new RuntimeException("Unable to update user elo");
    }

    protected void updateWins(User user, int plusWins) {
        String[] parameters = new String[] {String.valueOf(ONE), String.valueOf(plusWins), String.valueOf(user.getId())};
        int result;
        try {
            result = database.executeUpdate(UPDATE_WINS_SQL, parameters);
        } catch (SQLException e) {
            throw new RuntimeException("Unable to update user wins");
        }
        if (result != 1) throw new RuntimeException("Unable to update user wins");
    }

    private List<User> extractUsersFromResultSet(ResultSet resultSet) throws SQLException {
        List<User> userList = new ArrayList<>();
        while (resultSet.next()) {
            User user = new User(
                    resultSet.getInt("user_id"),
                    resultSet.getString("username"),
                    resultSet.getString("password"),
                    resultSet.getTimestamp("last_login"),
                    resultSet.getInt("coins"),
                    resultSet.getInt("elo"),
                    resultSet.getInt("games_played"),
                    resultSet.getInt("wins")
            );
            userList.add(user);
        }
        return userList;
    }

    private Optional<User> extractOptionalUserFromResultSet(String[] parameters, String sql) throws SQLException {
        ResultSet results = database.executeQuery(sql, parameters);
        if (results.next()) {
            User user = new User(
                    results.getInt("user_id"),
                    results.getString("username"),
                    results.getString("password"),
                    results.getTimestamp("last_login"),
                    results.getInt("coins"),
                    results.getInt("elo"),
                    results.getInt("games_played"),
                    results.getInt("wins")
            );
            return Optional.of(user);
        } else {
            return Optional.empty();
        }
    }
}