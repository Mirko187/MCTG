package at.technikum.apps.mtcg.casino;

import at.technikum.apps.mtcg.session.auth.AuthTokenService;
import at.technikum.apps.mtcg.interfaces.AbstractController;
import at.technikum.apps.mtcg.session.SessionService;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;

import java.sql.SQLException;

public class CasinoController extends AbstractController {

    private final CasinoService casinoService;

    public CasinoController(SessionService sessionService, CasinoService casinoService) {
        super(sessionService);
        this.casinoService = casinoService;
    }

    @Override
    public boolean supports(String route) {
        return route.startsWith("/casino");
    }

    @Override
    public Response handle(Request request) throws SQLException {

        if (request.getRoute().equals("/casino")) {
            switch (request.getMethod()) {
                case "POST": return play(request);
            }

            return status(HttpStatus.BAD_REQUEST);
        }


        return status(HttpStatus.BAD_REQUEST);
    }

    private Response play(Request request) {
        AuthTokenService authTokenService = AuthTokenService.getInstance();
        int w = casinoService.testYourLuck(authTokenService.getUserFromToken(request.getAuthorization()));
        Response response = new Response();
        response.setStatus(HttpStatus.OK);
        response.setBody("You won " + w + " Coins!!! Please play again soon you gambling addict");
        return response;
    }
}
