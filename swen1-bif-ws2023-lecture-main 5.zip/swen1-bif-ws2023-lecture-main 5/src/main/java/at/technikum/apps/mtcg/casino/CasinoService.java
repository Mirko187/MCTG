package at.technikum.apps.mtcg.casino;

import at.technikum.apps.mtcg.user.User;
import at.technikum.apps.mtcg.user.UserService;

import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.Random;

public class CasinoService {

    private final UserService userService;
    private final int COST_OF_GAMBLING = 5;
    private final int MINUS_ONE = -1;
    
    public CasinoService(UserService userService) {
        this.userService = userService;
    }

    public int testYourLuck(User user) {
        userService.updateCoinBalance(user, COST_OF_GAMBLING);
        Random random = new Random(Timestamp.valueOf(LocalDateTime.now()).getTime());
        int result = random.nextInt() % 10;
        if (result < 0) result = result * MINUS_ONE;
        int win = 0;
        
        switch (result) {
            case 0, 1, 2, 3: win = 0; break;
            case 4, 6, 5: win = 3; break;
            case 7, 8: win = 7; break;
            case 9: win = 20; break;
            default: win = 5; break;
        }
        userService.updateCoinBalance(user, win * (-1));
        return win;
    }
}
