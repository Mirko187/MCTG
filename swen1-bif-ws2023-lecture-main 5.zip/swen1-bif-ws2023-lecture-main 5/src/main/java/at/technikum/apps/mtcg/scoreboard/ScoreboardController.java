package at.technikum.apps.mtcg.scoreboard;

import at.technikum.apps.mtcg.interfaces.AbstractController;
import at.technikum.apps.mtcg.session.SessionService;
import at.technikum.apps.mtcg.user.User;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;
import at.technikum.apps.mtcg.scoreboard.*;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

public class ScoreboardController extends AbstractController {
    private final ScoreboardService scoreboardService;

    public ScoreboardController(SessionService sessionService, ScoreboardService scoreboardService) {
        super(sessionService);
        this.scoreboardService = scoreboardService;
    }

    public boolean supports(String route) {
        return route.equals("/scoreboard");
    }


    public Response handle(Request request) {
        Response response = new Response();

        if (request.getMethod().equals("GET") && request.getRoute().equals("/scoreboard")) {
            try {
                List<User> scoreboard = scoreboardService.getScoreboard();
                String scoreboardJson = convertScoreboardToJson(scoreboard);
                response.setStatus(HttpStatus.OK);
                response.setBody(scoreboardJson);
            } catch (Exception e) {
                e.printStackTrace();
                response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } else {
            response.setStatus(HttpStatus.BAD_REQUEST);
        }

        return response;
    }

    private String convertScoreboardToJson(List<User> scoreboard) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(scoreboard);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
