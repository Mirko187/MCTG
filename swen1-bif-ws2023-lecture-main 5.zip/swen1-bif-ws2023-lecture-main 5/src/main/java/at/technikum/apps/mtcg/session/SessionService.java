package at.technikum.apps.mtcg.session;

import at.technikum.apps.mtcg.session.auth.AuthTokenService;
import at.technikum.apps.mtcg.user.User;
import at.technikum.apps.mtcg.user.UserDAO;

import java.util.Optional;

public class SessionService {

    private final UserDAO userDAO;

    public SessionService(UserDAO userDAO) {
        this.userDAO = userDAO;
    }

    public LoginResponseWrapper loginUser(User user) {
        Optional<User> userOptional = userDAO.getByUsername(user.getUsername());
        if (userOptional.isEmpty()) {
            return new LoginResponseWrapper(null, false, false);
        }
        User actualUser = userOptional.get();
        if (!actualUser.getPassword().equals(user.getPassword())) {
            return new LoginResponseWrapper(null, true, false);
        }
        AuthTokenService authTokenService = AuthTokenService.getInstance();
        return new LoginResponseWrapper(authTokenService.createToken(actualUser), true, true);
    }

    public boolean verifyUserLoggedIn(String token) {
        AuthTokenService authTokenService = AuthTokenService.getInstance();
        return authTokenService.verifyAuthToken(token.split(" ")[1]);
    }
}
