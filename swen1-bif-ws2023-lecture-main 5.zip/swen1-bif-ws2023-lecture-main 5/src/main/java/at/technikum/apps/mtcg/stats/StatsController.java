package at.technikum.apps.mtcg.stats;

import at.technikum.apps.mtcg.interfaces.AbstractController;
import at.technikum.apps.mtcg.session.SessionService;
import at.technikum.apps.mtcg.session.auth.AuthTokenService;
import at.technikum.apps.mtcg.user.User;
import at.technikum.server.http.HttpStatus;
import at.technikum.server.http.Request;
import at.technikum.server.http.Response;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;

import java.util.List;

public class StatsController extends AbstractController {
    private final StatsService statsService;

    public StatsController(SessionService sessionService, StatsService statsService) {
        super(sessionService);
        this.statsService = statsService;
    }

    public boolean supports(String route) {
        return route.equals("/stats");
    }

    public Response handle(Request request) {
        Response response = new Response();

        if (request.getMethod().equals("GET") && request.getRoute().equals("/stats")) {
            try {
                AuthTokenService authTokenService = AuthTokenService.getInstance();
                User user = statsService.getStats(authTokenService.getUserFromToken(request.getAuthorization()));
                String statsJson = convertStatsToJson(user);
                response.setStatus(HttpStatus.OK);
                response.setBody(statsJson);
            } catch (Exception e) {
                e.printStackTrace();
                response.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
            }
        } else {
            response.setStatus(HttpStatus.BAD_REQUEST);
        }

        return response;
    }

    private String convertStatsToJson(User user) {
        ObjectMapper objectMapper = new ObjectMapper();
        try {
            return objectMapper.writeValueAsString(user);
        } catch (JsonProcessingException e) {
            throw new RuntimeException(e);
        }
    }
}
